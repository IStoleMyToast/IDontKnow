@echo off
title GLOWNY PROCES - NACISNIJ CTRL+C ABY ZATRZYMAC
mode con cols=50 lines=5
color 0C

:petla
echo [%time%] Spawnowanie nowego okna...
start "" "okienko.hta"
echo Nacisnij Ctrl+C w tym oknie, aby przerwac rozmnazanie.
timeout /t 1 > nul
goto petla